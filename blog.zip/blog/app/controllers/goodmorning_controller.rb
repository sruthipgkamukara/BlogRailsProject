class GoodmorningController < ApplicationController
  def wishing
  end
end
