require 'test_helper'

class GoodmorningControllerTest < ActionDispatch::IntegrationTest
  test "should get wishing" do
    get goodmorning_wishing_url
    assert_response :success
  end

end
